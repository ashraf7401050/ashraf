# Earn Money App - Architecture and Tech Stack

## High-Level Architecture
The application will consist of three main components:
1.  **Mobile/Web Frontend:** Cross-platform application for users to interact with the system.
2.  **Backend API:** Centralized server-side logic, handling user authentication, ad management, earnings, referrals, and withdrawals.
3.  **Admin Panel:** Web-based interface for the app owner to manage the application.

## Tech Stack Selection
-   **Frontend:** React Native (for cross-platform mobile and web compatibility).
-   **Backend:** Node.js with Express.js framework.
-   **Database:** PostgreSQL (for robust relational data management).
-   **Ad Integration:** Google AdMob (for mobile ads) and direct ad deals (for web/custom integrations).
-   **Payment Gateway:** PayPal API (for withdrawals).

## Initial Database Schema Design (Conceptual)

### Users Table
-   `user_id` (Primary Key)
-   `username`
-   `email`
-   `password_hash`
-   `referral_code`
-   `referred_by` (Foreign Key to `user_id`)
-   `current_balance`
-   `total_earnings`
-   `daily_ad_views`
-   `last_login`
-   `login_streak`
-   `is_premium`

### Ads Table
-   `ad_id` (Primary Key)
-   `ad_type` (e.g., video, banner)
-   `ad_content_url`
-   `ad_duration` (for video ads)
-   `points_per_view`
-   `ad_tier`
-   `target_audience`
-   `is_active`

### AdViews Table
-   `view_id` (Primary Key)
-   `user_id` (Foreign Key)
-   `ad_id` (Foreign Key)
-   `view_timestamp`
-   `points_earned`

### Transactions Table
-   `transaction_id` (Primary Key)
-   `user_id` (Foreign Key)
-   `type` (e.g., 'withdrawal', 'ad_earnings', 'referral_commission')
-   `amount`
-   `timestamp`
-   `status` (e.g., 'pending', 'completed', 'failed')
-   `payout_method`
-   `payout_details` (e.g., PayPal email, bank account info)

### Referrals Table
-   `referral_id` (Primary Key)
-   `referrer_id` (Foreign Key to `user_id`)
-   `referred_user_id` (Foreign Key to `user_id`)
-   `level` (1 for direct, 2 for indirect, etc.)
-   `commission_rate`
-   `earned_amount`

## Core API Endpoints (Conceptual)

### User Management
-   `POST /api/register`: User registration
-   `POST /api/login`: User login
-   `GET /api/user/profile`: Get user profile and earnings
-   `PUT /api/user/profile`: Update user profile

### Ad Viewing
-   `GET /api/ads/available`: Get list of available ads
-   `POST /api/ads/view`: Record ad view and award points

### Referral Program
-   `GET /api/referrals/my`: Get user's direct referrals
-   `GET /api/referrals/network`: Get multi-level referral network earnings

### Withdrawal System
-   `POST /api/withdraw`: Request a withdrawal
-   `GET /api/withdrawals/history`: Get withdrawal history

### Engagement Features
-   `POST /api/daily_bonus/claim`: Claim daily login bonus
-   `GET /api/streak_rewards`: Check streak rewards status

### Anti-Fraud
-   `POST /api/verify/captcha`: CAPTCHA verification endpoint

### Admin Endpoints (Internal/Protected)
-   `POST /admin/ads/create`: Create new ad
-   `PUT /admin/ads/:id`: Update ad status/details
-   `GET /admin/users`: Manage users
-   `GET /admin/transactions`: Manage payouts
-   `GET /admin/analytics`: Get analytics data


