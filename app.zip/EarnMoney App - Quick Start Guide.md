# EarnMoney App - Quick Start Guide

## Overview
This is a complete mobile/web application for earning money through ad viewing, referrals, and engagement activities.

## What's Included
- **Backend API** (Flask + MySQL) - Complete server with all endpoints
- **Frontend App** (React) - User interface for earning money
- **Admin Panel** (React) - Management interface for administrators
- **Documentation** - Comprehensive technical and user documentation

## Quick Start

### 1. Start the Backend
```bash
cd backend/earn_money_api
source venv/bin/activate
python src/main.py
```
Backend runs at: http://localhost:5000

### 2. Start the Frontend
```bash
cd frontend/earn-money-frontend
pnpm run dev --host
```
User app runs at: http://localhost:5173

### 3. Start the Admin Panel
```bash
cd admin/admin-panel
pnpm run dev --host --port 3001
```
Admin panel runs at: http://localhost:3001

## Test Accounts
- **Admin**: username: `admin`, password: `admin123`
- **User**: Create new account through the registration form

## Key Features
✅ User registration and authentication  
✅ Ad viewing with earnings (2-10 cents per ad)  
✅ Multi-level referral program (15% + 5% commissions)  
✅ Withdrawal system (PayPal, bank, gift cards)  
✅ Daily bonuses and streak rewards  
✅ Premium membership with enhanced earnings  
✅ Anti-fraud protection  
✅ Complete admin panel with analytics  
✅ Responsive design for mobile and desktop  

## File Structure
```
earn_money_app/
├── backend/earn_money_api/     # Flask API server
├── frontend/earn-money-frontend/   # React user app
├── admin/admin-panel/          # React admin interface
├── DOCUMENTATION.md            # Complete documentation
├── DOCUMENTATION.pdf           # PDF version
├── PROJECT_SUMMARY.md          # Technical overview
└── README.md                   # Architecture details
```

## Next Steps
1. Review the complete documentation (DOCUMENTATION.pdf)
2. Customize the design and branding
3. Configure production database
4. Set up payment processing
5. Deploy to production servers

## Support
All code is well-documented and includes comprehensive error handling. The modular architecture makes it easy to customize and extend functionality.

For detailed technical information, see DOCUMENTATION.pdf (47 pages of comprehensive documentation).

