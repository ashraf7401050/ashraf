from flask import Blueprint, jsonify, request
from src.models.user import User, Ad, Transaction, AdView, Referral, db
from datetime import datetime, timedelta
import jwt
import os

admin_bp = Blueprint('admin', __name__)

def get_admin_user_from_token():
    """Helper function to get admin user from JWT token"""
    token = request.headers.get('Authorization')
    if not token:
        return None
    
    if token.startswith('Bearer '):
        token = token[7:]
    
    try:
        data = jwt.decode(token, os.getenv('SECRET_KEY', 'asdf#FGSgvasgf$5$WGT'), algorithms=['HS256'])
        user = User.query.get(data['user_id'])
        # For demo purposes, admin is user with id=1 or username='admin'
        if user and (user.id == 1 or user.username == 'admin'):
            return user
        return None
    except:
        return None

@admin_bp.route('/dashboard', methods=['GET'])
def get_dashboard_stats():
    try:
        admin_user = get_admin_user_from_token()
        if not admin_user:
            return jsonify({'error': 'Admin authentication required'}), 401
        
        # Get basic stats
        total_users = User.query.count()
        total_ads = Ad.query.count()
        active_ads = Ad.query.filter_by(is_active=True).count()
        
        # Get earnings stats
        total_earnings = db.session.query(db.func.sum(Transaction.amount))\
                                 .filter(Transaction.transaction_type.in_(['ad_earnings', 'referral_commission', 'daily_bonus']))\
                                 .scalar() or 0
        
        total_withdrawals = db.session.query(db.func.sum(Transaction.amount))\
                                    .filter_by(transaction_type='withdrawal')\
                                    .scalar() or 0
        
        # Get recent activity (last 7 days)
        week_ago = datetime.utcnow() - timedelta(days=7)
        recent_users = User.query.filter(User.created_at >= week_ago).count()
        recent_ad_views = AdView.query.filter(AdView.view_timestamp >= week_ago).count()
        
        return jsonify({
            'total_users': total_users,
            'total_ads': total_ads,
            'active_ads': active_ads,
            'total_earnings_paid': total_earnings,
            'total_withdrawals': total_withdrawals,
            'new_users_this_week': recent_users,
            'ad_views_this_week': recent_ad_views
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/ads', methods=['GET'])
def get_all_ads():
    try:
        admin_user = get_admin_user_from_token()
        if not admin_user:
            return jsonify({'error': 'Admin authentication required'}), 401
        
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        ads = Ad.query.order_by(Ad.created_at.desc())\
                     .paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'ads': [ad.to_dict() for ad in ads.items],
            'total': ads.total,
            'pages': ads.pages,
            'current_page': page
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/ads', methods=['POST'])
def create_ad():
    try:
        admin_user = get_admin_user_from_token()
        if not admin_user:
            return jsonify({'error': 'Admin authentication required'}), 401
        
        data = request.json
        
        ad = Ad(
            title=data.get('title'),
            description=data.get('description'),
            ad_type=data.get('ad_type'),
            content_url=data.get('content_url'),
            duration=data.get('duration', 30),
            points_per_view=data.get('points_per_view'),
            ad_tier=data.get('ad_tier', 'basic'),
            target_audience=data.get('target_audience'),
            is_active=data.get('is_active', True)
        )
        
        db.session.add(ad)
        db.session.commit()
        
        return jsonify({
            'message': 'Ad created successfully',
            'ad': ad.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/ads/<int:ad_id>', methods=['PUT'])
def update_ad(ad_id):
    try:
        admin_user = get_admin_user_from_token()
        if not admin_user:
            return jsonify({'error': 'Admin authentication required'}), 401
        
        ad = Ad.query.get_or_404(ad_id)
        data = request.json
        
        ad.title = data.get('title', ad.title)
        ad.description = data.get('description', ad.description)
        ad.ad_type = data.get('ad_type', ad.ad_type)
        ad.content_url = data.get('content_url', ad.content_url)
        ad.duration = data.get('duration', ad.duration)
        ad.points_per_view = data.get('points_per_view', ad.points_per_view)
        ad.ad_tier = data.get('ad_tier', ad.ad_tier)
        ad.target_audience = data.get('target_audience', ad.target_audience)
        ad.is_active = data.get('is_active', ad.is_active)
        
        db.session.commit()
        
        return jsonify({
            'message': 'Ad updated successfully',
            'ad': ad.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/users', methods=['GET'])
def get_all_users():
    try:
        admin_user = get_admin_user_from_token()
        if not admin_user:
            return jsonify({'error': 'Admin authentication required'}), 401
        
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        users = User.query.order_by(User.created_at.desc())\
                         .paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'users': [user.to_dict() for user in users.items],
            'total': users.total,
            'pages': users.pages,
            'current_page': page
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/transactions', methods=['GET'])
def get_all_transactions():
    try:
        admin_user = get_admin_user_from_token()
        if not admin_user:
            return jsonify({'error': 'Admin authentication required'}), 401
        
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        transaction_type = request.args.get('type')
        
        query = Transaction.query
        if transaction_type:
            query = query.filter_by(transaction_type=transaction_type)
        
        transactions = query.order_by(Transaction.timestamp.desc())\
                           .paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'transactions': [transaction.to_dict() for transaction in transactions.items],
            'total': transactions.total,
            'pages': transactions.pages,
            'current_page': page
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/transactions/<int:transaction_id>/approve', methods=['POST'])
def approve_withdrawal(transaction_id):
    try:
        admin_user = get_admin_user_from_token()
        if not admin_user:
            return jsonify({'error': 'Admin authentication required'}), 401
        
        transaction = Transaction.query.get_or_404(transaction_id)
        
        if transaction.transaction_type != 'withdrawal':
            return jsonify({'error': 'Only withdrawal transactions can be approved'}), 400
        
        if transaction.status != 'pending':
            return jsonify({'error': 'Transaction is not pending'}), 400
        
        transaction.status = 'completed'
        transaction.reference_id = f"ADMIN_APPROVED_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}"
        
        db.session.commit()
        
        return jsonify({
            'message': 'Withdrawal approved successfully',
            'transaction': transaction.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/analytics', methods=['GET'])
def get_analytics():
    try:
        admin_user = get_admin_user_from_token()
        if not admin_user:
            return jsonify({'error': 'Admin authentication required'}), 401
        
        # Get daily stats for last 30 days
        thirty_days_ago = datetime.utcnow() - timedelta(days=30)
        
        daily_stats = db.session.query(
            db.func.date(AdView.view_timestamp).label('date'),
            db.func.count(AdView.id).label('ad_views'),
            db.func.sum(AdView.points_earned).label('points_paid')
        ).filter(AdView.view_timestamp >= thirty_days_ago)\
         .group_by(db.func.date(AdView.view_timestamp))\
         .all()
        
        # Get top performing ads
        top_ads = db.session.query(
            Ad.title,
            db.func.count(AdView.id).label('total_views'),
            db.func.sum(AdView.points_earned).label('total_points')
        ).join(AdView)\
         .filter(AdView.view_timestamp >= thirty_days_ago)\
         .group_by(Ad.id, Ad.title)\
         .order_by(db.func.count(AdView.id).desc())\
         .limit(10)\
         .all()
        
        return jsonify({
            'daily_stats': [
                {
                    'date': stat.date.isoformat(),
                    'ad_views': stat.ad_views,
                    'points_paid': float(stat.points_paid or 0)
                } for stat in daily_stats
            ],
            'top_ads': [
                {
                    'title': ad.title,
                    'total_views': ad.total_views,
                    'total_points': float(ad.total_points or 0)
                } for ad in top_ads
            ]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

