from flask import Blueprint, jsonify, request
from src.models.user import User, Ad, AdView, Transaction, db
from datetime import datetime, date
import jwt
import os
import random

ads_bp = Blueprint('ads', __name__)

def get_user_from_token():
    """Helper function to get user from JWT token"""
    token = request.headers.get('Authorization')
    if not token:
        return None
    
    if token.startswith('Bearer '):
        token = token[7:]
    
    try:
        data = jwt.decode(token, os.getenv('SECRET_KEY', 'asdf#FGSgvasgf$5$WGT'), algorithms=['HS256'])
        return User.query.get(data['user_id'])
    except:
        return None

@ads_bp.route('/available', methods=['GET'])
def get_available_ads():
    try:
        user = get_user_from_token()
        if not user:
            return jsonify({'error': 'Authentication required'}), 401
        
        # Check daily ad view limit (e.g., 50 ads per day)
        daily_limit = 100 if user.is_premium else 50
        if user.daily_ad_views >= daily_limit:
            return jsonify({
                'message': 'Daily ad view limit reached',
                'daily_limit': daily_limit,
                'views_today': user.daily_ad_views
            }), 200
        
        # Get active ads, prioritize higher-tier ads for premium users
        query = Ad.query.filter_by(is_active=True)
        
        if user.is_premium:
            # Premium users get access to higher-paying ads
            ads = query.filter(Ad.ad_tier.in_(['premium', 'vip', 'basic'])).all()
        else:
            ads = query.filter(Ad.ad_tier.in_(['basic', 'premium'])).all()
        
        # Randomize ad order to ensure fair distribution
        random.shuffle(ads)
        
        return jsonify({
            'ads': [ad.to_dict() for ad in ads[:10]],  # Return max 10 ads at a time
            'daily_views_remaining': daily_limit - user.daily_ad_views
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@ads_bp.route('/view', methods=['POST'])
def record_ad_view():
    try:
        user = get_user_from_token()
        if not user:
            return jsonify({'error': 'Authentication required'}), 401
        
        data = request.json
        ad_id = data.get('ad_id')
        view_duration = data.get('view_duration', 0)
        
        if not ad_id:
            return jsonify({'error': 'Ad ID is required'}), 400
        
        ad = Ad.query.get(ad_id)
        if not ad or not ad.is_active:
            return jsonify({'error': 'Ad not found or inactive'}), 404
        
        # Check daily limit
        daily_limit = 100 if user.is_premium else 50
        if user.daily_ad_views >= daily_limit:
            return jsonify({'error': 'Daily ad view limit reached'}), 400
        
        # Verify minimum view duration (80% of ad duration)
        min_duration = ad.duration * 0.8
        if view_duration < min_duration:
            return jsonify({'error': 'Insufficient view duration'}), 400
        
        # Calculate points earned (premium users get 20% bonus)
        points_earned = ad.points_per_view
        if user.is_premium:
            points_earned *= 1.2
        
        # Record ad view
        ad_view = AdView(
            user_id=user.id,
            ad_id=ad.id,
            points_earned=points_earned,
            is_verified=True
        )
        db.session.add(ad_view)
        
        # Update user balance and stats
        user.current_balance += points_earned
        user.total_earnings += points_earned
        user.daily_ad_views += 1
        
        # Create transaction record
        transaction = Transaction(
            user_id=user.id,
            transaction_type='ad_earnings',
            amount=points_earned,
            status='completed'
        )
        db.session.add(transaction)
        
        # Process referral commissions
        from src.models.user import Referral
        referrals = Referral.query.filter_by(referred_user_id=user.id).all()
        
        for referral in referrals:
            commission = points_earned * (referral.commission_rate / 100)
            referrer = User.query.get(referral.referrer_id)
            
            if referrer:
                referrer.current_balance += commission
                referrer.total_earnings += commission
                referral.total_earned += commission
                
                # Create commission transaction
                commission_transaction = Transaction(
                    user_id=referrer.id,
                    transaction_type='referral_commission',
                    amount=commission,
                    status='completed'
                )
                db.session.add(commission_transaction)
        
        db.session.commit()
        
        return jsonify({
            'message': 'Ad view recorded successfully',
            'points_earned': points_earned,
            'new_balance': user.current_balance,
            'daily_views_remaining': daily_limit - user.daily_ad_views
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@ads_bp.route('/history', methods=['GET'])
def get_ad_history():
    try:
        user = get_user_from_token()
        if not user:
            return jsonify({'error': 'Authentication required'}), 401
        
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        ad_views = AdView.query.filter_by(user_id=user.id)\
                              .order_by(AdView.view_timestamp.desc())\
                              .paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'ad_views': [view.to_dict() for view in ad_views.items],
            'total': ad_views.total,
            'pages': ad_views.pages,
            'current_page': page
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

