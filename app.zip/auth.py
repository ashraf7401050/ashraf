from flask import Blueprint, jsonify, request
from werkzeug.security import check_password_hash
from src.models.user import User, db
from datetime import datetime, date
import jwt
import os

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/register', methods=['POST'])
def register():
    try:
        data = request.json
        username = data.get('username')
        email = data.get('email')
        password = data.get('password')
        referral_code = data.get('referral_code')
        
        # Validation
        if not username or not email or not password:
            return jsonify({'error': 'Username, email, and password are required'}), 400
        
        # Check if user already exists
        if User.query.filter_by(username=username).first():
            return jsonify({'error': 'Username already exists'}), 400
        
        if User.query.filter_by(email=email).first():
            return jsonify({'error': 'Email already exists'}), 400
        
        # Find referrer if referral code provided
        referred_by = None
        if referral_code:
            referrer = User.query.filter_by(referral_code=referral_code).first()
            if referrer:
                referred_by = referrer.id
        
        # Create new user
        user = User(username=username, email=email, password=password, referred_by=referred_by)
        db.session.add(user)
        db.session.commit()
        
        # Create referral relationships if user was referred
        if referred_by:
            from src.models.user import Referral
            # Direct referral (level 1)
            referral = Referral(
                referrer_id=referred_by,
                referred_user_id=user.id,
                level=1,
                commission_rate=15.0  # 15% commission for direct referrals
            )
            db.session.add(referral)
            
            # Check for indirect referral (level 2)
            referrer = User.query.get(referred_by)
            if referrer.referred_by:
                indirect_referral = Referral(
                    referrer_id=referrer.referred_by,
                    referred_user_id=user.id,
                    level=2,
                    commission_rate=5.0  # 5% commission for indirect referrals
                )
                db.session.add(indirect_referral)
            
            db.session.commit()
        
        return jsonify({
            'message': 'User registered successfully',
            'user': user.to_dict()
        }), 201
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/login', methods=['POST'])
def login():
    try:
        data = request.json
        username = data.get('username')
        password = data.get('password')
        
        if not username or not password:
            return jsonify({'error': 'Username and password are required'}), 400
        
        user = User.query.filter_by(username=username).first()
        
        if not user or not user.check_password(password):
            return jsonify({'error': 'Invalid credentials'}), 401
        
        # Update login streak
        today = date.today()
        if user.last_login and user.last_login.date() == today - datetime.timedelta(days=1):
            user.login_streak += 1
        elif not user.last_login or user.last_login.date() != today:
            user.login_streak = 1
        
        user.last_login = datetime.utcnow()
        user.daily_ad_views = 0  # Reset daily ad views
        db.session.commit()
        
        # Generate JWT token
        token = jwt.encode({
            'user_id': user.id,
            'username': user.username
        }, os.getenv('SECRET_KEY', 'asdf#FGSgvasgf$5$WGT'), algorithm='HS256')
        
        return jsonify({
            'message': 'Login successful',
            'token': token,
            'user': user.to_dict()
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/profile', methods=['GET'])
def get_profile():
    try:
        token = request.headers.get('Authorization')
        if not token:
            return jsonify({'error': 'Token is missing'}), 401
        
        if token.startswith('Bearer '):
            token = token[7:]
        
        data = jwt.decode(token, os.getenv('SECRET_KEY', 'asdf#FGSgvasgf$5$WGT'), algorithms=['HS256'])
        user = User.query.get(data['user_id'])
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        return jsonify(user.to_dict()), 200
        
    except jwt.ExpiredSignatureError:
        return jsonify({'error': 'Token has expired'}), 401
    except jwt.InvalidTokenError:
        return jsonify({'error': 'Invalid token'}), 401
    except Exception as e:
        return jsonify({'error': str(e)}), 500

