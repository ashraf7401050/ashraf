from flask import Blueprint, jsonify, request
from src.models.user import User, Transaction, db
from datetime import datetime, date, timedelta
import jwt
import os

engagement_bp = Blueprint('engagement', __name__)

def get_user_from_token():
    """Helper function to get user from JWT token"""
    token = request.headers.get('Authorization')
    if not token:
        return None
    
    if token.startswith('Bearer '):
        token = token[7:]
    
    try:
        data = jwt.decode(token, os.getenv('SECRET_KEY', 'asdf#FGSgvasgf$5$WGT'), algorithms=['HS256'])
        return User.query.get(data['user_id'])
    except:
        return None

@engagement_bp.route('/daily-bonus/claim', methods=['POST'])
def claim_daily_bonus():
    try:
        user = get_user_from_token()
        if not user:
            return jsonify({'error': 'Authentication required'}), 401
        
        today = date.today()
        
        # Check if user already claimed bonus today
        if user.last_daily_bonus == today:
            return jsonify({'error': 'Daily bonus already claimed today'}), 400
        
        # Calculate bonus amount based on login streak
        base_bonus = 0.05  # $0.05 base bonus
        streak_multiplier = min(user.login_streak / 10, 2.0)  # Max 2x multiplier at 20-day streak
        bonus_amount = base_bonus * (1 + streak_multiplier)
        
        # Premium users get 50% bonus
        if user.is_premium:
            bonus_amount *= 1.5
        
        # Update user balance
        user.current_balance += bonus_amount
        user.total_earnings += bonus_amount
        user.last_daily_bonus = today
        
        # Create transaction record
        transaction = Transaction(
            user_id=user.id,
            transaction_type='daily_bonus',
            amount=bonus_amount,
            status='completed'
        )
        db.session.add(transaction)
        db.session.commit()
        
        return jsonify({
            'message': 'Daily bonus claimed successfully',
            'bonus_amount': bonus_amount,
            'new_balance': user.current_balance,
            'login_streak': user.login_streak
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@engagement_bp.route('/daily-bonus/status', methods=['GET'])
def get_daily_bonus_status():
    try:
        user = get_user_from_token()
        if not user:
            return jsonify({'error': 'Authentication required'}), 401
        
        today = date.today()
        can_claim = user.last_daily_bonus != today
        
        # Calculate potential bonus
        base_bonus = 0.05
        streak_multiplier = min(user.login_streak / 10, 2.0)
        bonus_amount = base_bonus * (1 + streak_multiplier)
        
        if user.is_premium:
            bonus_amount *= 1.5
        
        return jsonify({
            'can_claim': can_claim,
            'potential_bonus': bonus_amount,
            'login_streak': user.login_streak,
            'last_claimed': user.last_daily_bonus.isoformat() if user.last_daily_bonus else None
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@engagement_bp.route('/streak-rewards', methods=['GET'])
def get_streak_rewards():
    try:
        user = get_user_from_token()
        if not user:
            return jsonify({'error': 'Authentication required'}), 401
        
        # Define streak milestones and rewards
        streak_rewards = [
            {'days': 7, 'reward': 0.25, 'type': 'bonus'},
            {'days': 14, 'reward': 0.50, 'type': 'bonus'},
            {'days': 30, 'reward': 1.00, 'type': 'bonus'},
            {'days': 60, 'reward': 2.50, 'type': 'bonus'},
            {'days': 100, 'reward': 5.00, 'type': 'bonus'}
        ]
        
        # Check which rewards user has earned
        earned_rewards = []
        available_rewards = []
        
        for reward in streak_rewards:
            if user.login_streak >= reward['days']:
                earned_rewards.append(reward)
            else:
                available_rewards.append(reward)
        
        return jsonify({
            'current_streak': user.login_streak,
            'earned_rewards': earned_rewards,
            'upcoming_rewards': available_rewards[:3]  # Show next 3 milestones
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@engagement_bp.route('/referrals/my', methods=['GET'])
def get_my_referrals():
    try:
        user = get_user_from_token()
        if not user:
            return jsonify({'error': 'Authentication required'}), 401
        
        # Get direct referrals
        direct_referrals = User.query.filter_by(referred_by=user.id).all()
        
        # Get referral earnings
        from src.models.user import Referral
        referral_earnings = db.session.query(Referral)\
                                    .filter_by(referrer_id=user.id)\
                                    .all()
        
        total_commission = sum(r.total_earned for r in referral_earnings)
        
        return jsonify({
            'referral_code': user.referral_code,
            'direct_referrals': len(direct_referrals),
            'total_commission_earned': total_commission,
            'referrals': [
                {
                    'username': ref.username,
                    'joined_date': ref.created_at.isoformat(),
                    'total_earnings': ref.total_earnings
                } for ref in direct_referrals
            ]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@engagement_bp.route('/stats', methods=['GET'])
def get_user_stats():
    try:
        user = get_user_from_token()
        if not user:
            return jsonify({'error': 'Authentication required'}), 401
        
        # Get earnings for last 30 days
        thirty_days_ago = datetime.utcnow() - timedelta(days=30)
        recent_earnings = db.session.query(Transaction)\
                                  .filter_by(user_id=user.id)\
                                  .filter(Transaction.transaction_type.in_(['ad_earnings', 'referral_commission', 'daily_bonus']))\
                                  .filter(Transaction.timestamp >= thirty_days_ago)\
                                  .all()
        
        monthly_earnings = sum(t.amount for t in recent_earnings)
        
        # Get ad views for today
        from src.models.user import AdView
        today_start = datetime.combine(date.today(), datetime.min.time())
        today_ad_views = AdView.query.filter_by(user_id=user.id)\
                                   .filter(AdView.view_timestamp >= today_start)\
                                   .count()
        
        return jsonify({
            'current_balance': user.current_balance,
            'total_earnings': user.total_earnings,
            'monthly_earnings': monthly_earnings,
            'login_streak': user.login_streak,
            'today_ad_views': today_ad_views,
            'daily_ad_limit': 100 if user.is_premium else 50,
            'is_premium': user.is_premium
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

