import os
import sys
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory
from flask_cors import CORS
from src.models.user import db
from src.routes.auth import auth_bp
from src.routes.ads import ads_bp
from src.routes.withdrawal import withdrawal_bp
from src.routes.engagement import engagement_bp
from src.routes.admin import admin_bp

app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))
app.config['SECRET_KEY'] = 'asdf#FGSgvasgf$5$WGT'

# Enable CORS for all routes
CORS(app, origins="*")

# Register blueprints
app.register_blueprint(auth_bp, url_prefix='/api/auth')
app.register_blueprint(ads_bp, url_prefix='/api/ads')
app.register_blueprint(withdrawal_bp, url_prefix='/api/withdrawal')
app.register_blueprint(engagement_bp, url_prefix='/api/engagement')
app.register_blueprint(admin_bp, url_prefix='/api/admin')

# Database configuration
app.config['SQLALCHEMY_DATABASE_URI'] = f"mysql+pymysql://{os.getenv('DB_USERNAME', 'root')}:{os.getenv('DB_PASSWORD', 'password')}@{os.getenv('DB_HOST', 'localhost')}:{os.getenv('DB_PORT', '3306')}/{os.getenv('DB_NAME', 'mydb')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

# Create tables and sample data
with app.app_context():
    db.create_all()
    
    # Create sample ads if none exist
    from src.models.user import Ad
    if Ad.query.count() == 0:
        sample_ads = [
            Ad(
                title="Watch and Earn - Mobile Game Ad",
                description="30-second mobile game advertisement",
                ad_type="video",
                content_url="https://example.com/ad1.mp4",
                duration=30,
                points_per_view=0.02,
                ad_tier="basic"
            ),
            Ad(
                title="Premium Shopping Deal",
                description="High-value shopping advertisement",
                ad_type="video",
                content_url="https://example.com/ad2.mp4",
                duration=45,
                points_per_view=0.05,
                ad_tier="premium"
            ),
            Ad(
                title="VIP Investment Opportunity",
                description="Exclusive investment platform ad",
                ad_type="video",
                content_url="https://example.com/ad3.mp4",
                duration=60,
                points_per_view=0.10,
                ad_tier="vip"
            )
        ]
        
        for ad in sample_ads:
            db.session.add(ad)
        
        db.session.commit()

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    static_folder_path = app.static_folder
    if static_folder_path is None:
            return "Static folder not configured", 404

    if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
        return send_from_directory(static_folder_path, path)
    else:
        index_path = os.path.join(static_folder_path, 'index.html')
        if os.path.exists(index_path):
            return send_from_directory(static_folder_path, 'index.html')
        else:
            return "index.html not found", 404


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

