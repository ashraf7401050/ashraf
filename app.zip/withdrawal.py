from flask import Blueprint, jsonify, request
from src.models.user import User, Transaction, db
import jwt
import os
import json

withdrawal_bp = Blueprint('withdrawal', __name__)

def get_user_from_token():
    """Helper function to get user from JWT token"""
    token = request.headers.get('Authorization')
    if not token:
        return None
    
    if token.startswith('Bearer '):
        token = token[7:]
    
    try:
        data = jwt.decode(token, os.getenv('SECRET_KEY', 'asdf#FGSgvasgf$5$WGT'), algorithms=['HS256'])
        return User.query.get(data['user_id'])
    except:
        return None

@withdrawal_bp.route('/request', methods=['POST'])
def request_withdrawal():
    try:
        user = get_user_from_token()
        if not user:
            return jsonify({'error': 'Authentication required'}), 401
        
        data = request.json
        amount = data.get('amount')
        payout_method = data.get('payout_method')
        payout_details = data.get('payout_details')
        
        # Validation
        if not amount or not payout_method or not payout_details:
            return jsonify({'error': 'Amount, payout method, and payout details are required'}), 400
        
        # Check minimum withdrawal amount
        min_withdrawal = 1.0  # $1 minimum
        if amount < min_withdrawal:
            return jsonify({'error': f'Minimum withdrawal amount is ${min_withdrawal}'}), 400
        
        # Check if user has sufficient balance
        if user.current_balance < amount:
            return jsonify({'error': 'Insufficient balance'}), 400
        
        # Validate payout method
        valid_methods = ['paypal', 'bank_transfer', 'gift_card']
        if payout_method not in valid_methods:
            return jsonify({'error': 'Invalid payout method'}), 400
        
        # Create withdrawal transaction
        transaction = Transaction(
            user_id=user.id,
            transaction_type='withdrawal',
            amount=amount,
            status='pending',
            payout_method=payout_method,
            payout_details=json.dumps(payout_details)
        )
        db.session.add(transaction)
        
        # Deduct amount from user balance
        user.current_balance -= amount
        db.session.commit()
        
        return jsonify({
            'message': 'Withdrawal request submitted successfully',
            'transaction_id': transaction.id,
            'amount': amount,
            'status': 'pending',
            'new_balance': user.current_balance
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@withdrawal_bp.route('/history', methods=['GET'])
def get_withdrawal_history():
    try:
        user = get_user_from_token()
        if not user:
            return jsonify({'error': 'Authentication required'}), 401
        
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        withdrawals = Transaction.query.filter_by(
            user_id=user.id,
            transaction_type='withdrawal'
        ).order_by(Transaction.timestamp.desc())\
         .paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'withdrawals': [withdrawal.to_dict() for withdrawal in withdrawals.items],
            'total': withdrawals.total,
            'pages': withdrawals.pages,
            'current_page': page
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@withdrawal_bp.route('/methods', methods=['GET'])
def get_withdrawal_methods():
    """Get available withdrawal methods and their requirements"""
    return jsonify({
        'methods': [
            {
                'id': 'paypal',
                'name': 'PayPal',
                'min_amount': 1.0,
                'processing_time': '1-3 business days',
                'required_fields': ['email']
            },
            {
                'id': 'bank_transfer',
                'name': 'Bank Transfer',
                'min_amount': 5.0,
                'processing_time': '3-5 business days',
                'required_fields': ['account_number', 'routing_number', 'account_holder_name']
            },
            {
                'id': 'gift_card',
                'name': 'Gift Card',
                'min_amount': 1.0,
                'processing_time': '1-2 business days',
                'required_fields': ['card_type', 'email']
            }
        ]
    }), 200

